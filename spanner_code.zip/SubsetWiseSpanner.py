
# coding: utf-8

# # Subset Spanner Problem
# 
# __Probelm Statement:__ Given an undirected graph $G=(V,E)$, a set of terminal nodes $T$, and a cost function $c: E\mapsto \mathbb{R}^+$, find a spanner $G'\subset G$ that connects the terminal nodes with the minimal cost while preserving the pairwise distances within a stretch factor $t$.
# 
# This problem is NP-hard. However, approximation algorithms exists for the Steiner tree problem. In particular, a 2-approximation algorithm is as follows:
# 
# __2-Approximation Algorithm:__ Build an auxiliary graph $\mathcal{G}=(T,{T \choose 2},w)$, where the edge weights are equal to the shortest path length in graph $G$, i.e., $w(u,v)=d_G(u,v)$ for any $u,v\in T$. Find a $t-$spanner of $\mathcal{G}$. Then preserve the distances among edges of $\mathcal{G}'$ in $G$.

# Here we generate a weighted graph.

# In[5]:

import networkx as nx
import copy
#import matplotlib.pyplot as plt
from random import *

G=nx.Graph()
G0=nx.random_geometric_graph(400,.2)

G.add_nodes_from(G0);
for e in G0.edges():
    G.add_edge(e[0],e[1],weight=1+3*random())


# This is how it looks.

# In[6]:

#get_ipython().run_cell_magic('capture', '--no-display', "\npos=nx.spring_layout(G, k=.015, weight='weight')\n\nplt.figure(figsize=(8, 6))\nnx.draw(G, pos=pos, node_size=10, node_color='red')\nplt.title('This is the graph', size=15)\nplt.show()")


# Here we compute a spanner of the graph.

# In[20]:

def distance(G,i,j,weight):
    try:
        return nx.shortest_path_length(G,i,j,weight)
    except nx.NetworkXNoPath:
        return float('inf')

def tspanner(G,t,weight):# Create empty graph
    Gt = nx.create_empty_copy(G)
    for e in sorted(G.edges(data=True),key=lambda x:x[2][weight]):
        if e[2][weight]*t<distance(Gt,e[0],e[1],weight):
            Gt.add_edge(e[0],e[1],attr_dict=e[2])
    return Gt


# In[21]:

t=3
Gt=tspanner(G,t,'weight')
print(len(Gt.edges()),len(G.edges()))


# In[19]:

pos_s=nx.spring_layout(Gt, k=.015, weight='weight')

#plt.figure(figsize=(8, 6))
#nx.draw(Gt, pos=pos, node_size=10, node_color='red')
#plt.title('This is a t-spanner of G', size=15)
#plt.show()


# Now, let's compute a subset spanner of $G$.

# In[96]:

from networkx.algorithms import approximation as nxaa
import itertools

def pairwise(iterable):
    "s -> (s0,s1), (s1,s2), (s2, s3), ..."
    a, b = itertools.tee(iterable)
    next(b, None)
    return itertools.izip(a, b)

def SubsetSpanner(G,terminal_nodes,t,weight):
    M = nxaa.steinertree.metric_closure(G, weight=weight)
    H = M.subgraph(terminal_nodes)
    #print(H.edges(data=True))
    
    tspanner_edges = tspanner(H, t, 'distance')
    dummy=nx.get_edge_attributes(tspanner_edges,'attr_dict')
    edges=[];
    for d in dummy.values():
        path=d['path']
        for i in range(1,len(path)):
            edges.append((path[i-1],path[i]))
    
    GSt = G.edge_subgraph(edges)
    return GSt
    


# In[105]:

import random

terminal_nodes = random.sample(G.nodes(),100)
print(terminal_nodes)

GSt = SubsetSpanner(G,terminal_nodes,t,'weight')


# In[106]:

#plt.figure(figsize=(8, 6))
#nx.draw(GSt, pos=pos, node_size=10, node_color='red')
#plt.title('This is a subset t-spanner of G', size=15)
#plt.show()


# In[ ]:



