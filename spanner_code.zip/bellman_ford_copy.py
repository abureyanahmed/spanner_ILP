import networkx as nx
from input_functions import *

def bellman_ford(G_cspp, MAX_WEIGHT, MAX_COST, s, d):
 my_inf = 10000000
 #min cost to path with t hops s->v : d[v, t]
 dis = []
 par = []
 # vertex set 0, 2, ..., n-1
 n = len(G_cspp.nodes())
 for i in range(0, n):
  dis.append([])
  par.append([])
  for j in range(0, MAX_WEIGHT+1):
   if i==s and j==0:
    dis[i].append(0)
    par[i].append(-1)
   else:
    dis[i].append(my_inf)
    par[i].append(-1)
 #print(dis)
 m = len(G_cspp.edges())
 #for i=1 to n-1
 for i in range(0, n-1):
  #for t=1 to 10n
  for t in range(0, MAX_WEIGHT+1):
   #for (u,v) in E
   for u, v in G_cspp.edges():
    #d[v, t] = min{d[v, t], d[u, t-1]+w(w,v)}
    if t-G_cspp[u][v]['weight']<0:
     continue
    if dis[v][t] > dis[u][t-G_cspp[u][v]['weight']] + G_cspp[u][v]['cost']:
     par[v][t] = u
     dis[v][t] = dis[u][t-G_cspp[u][v]['weight']] + G_cspp[u][v]['cost']
 min_t_i = -1
 for i in range(MAX_WEIGHT+1):
  if dis[d][i]<=MAX_COST:
   min_t_i = i
   break
 cost = -1
 temp = nx.Graph()
 if min_t_i!=-1:
  cost = dis[d][min_t_i]
  curr_t = min_t_i
  curr_node = d
  curr_par = par[d][curr_t]
  while curr_par!=-1:
   temp.add_edge(curr_par, curr_node, weight=G_cspp[curr_par][curr_node]['weight'], cost=G_cspp[curr_par][curr_node]['cost'])
   #print(curr_par, curr_node, G_cspp[curr_par][curr_node]['weight'], G_cspp[curr_par][curr_node]['cost'])
   curr_t = curr_t - G_cspp[curr_par][curr_node]['weight']
   curr_node = curr_par
   curr_par = par[curr_node][curr_t]
 return (temp, cost, min_t_i)

#G, subset_arr = build_networkx_graph('erdos_renyi_sm2/graph_1.txt')
#print('nodes:', G.nodes())
#print('edges:', G.edges())
#for u,v in G.edges():
# print(u, v)

#G = nx.Graph()
#G.add_edge(0, 1, weight=2, cost=1)
#G.add_edge(1, 2, weight=2, cost=1)
#G.add_edge(1, 2, weight=1, cost=2)
#G.add_edge(2, 3, weight=2, cost=1)
#G.add_edge(2, 3, weight=1, cost=2)
#G.add_edge(3, 4, weight=2, cost=1)
#G.add_edge(3, 4, weight=1, cost=2)
#G.add_edge(4, 5, weight=2, cost=1)
#G.add_edge(4, 5, weight=1, cost=2)
#print(bellman_ford(G, 100, 20, 1, 5))


