import networkx as nx
from input_functions import *

def path_comparison(p, sub_pth):
  if len(p)!=len(sub_pth):
    return False
  matched = True
  for j in range(len(p)):
    if not p[j] == sub_pth[j]:
      matched = False
  if not matched:
    matched = True
    for j in range(len(p)):
      t = len(p)-j-1
      if not p[t] == sub_pth[j]:
        matched = False
  return matched

def bellman_ford(G_cspp, MAX_WEIGHT, MAX_COST, s, d, init_path_arr, l):
 RC_EPS = 1.0e-6
 #RC_EPS = .5
 for pth in nx.all_simple_paths(G_cspp, s, d):
  cost = 0
  wgt = 0
  temp = nx.Graph()
  for i in range(1, len(pth)):
   u = pth[i-1]
   v = pth[i]
   temp.add_edge(u, v, weight=G_cspp[u][v]['weight'], cost=G_cspp[u][v]['cost'])
   cost += G_cspp[u][v]['cost']
   wgt += G_cspp[u][v]['weight']
  if cost<MAX_COST+RC_EPS and wgt<=MAX_WEIGHT:
   diff_path = True
   for p in init_path_arr[l]:
    matched = path_comparison(p, pth)
    if matched:
     diff_path = False
     break
   if diff_path:
    return (temp, cost, wgt)
 return (temp, -1, -1)

def bellman_ford_old(G_cspp, MAX_WEIGHT, MAX_COST, s, d, init_path_arr, l):
 #RC_EPS = 1.0e-6
 RC_EPS = .5
 #MAX_HOP = 10
 #MAX_HOP = 11
 MAX_HOP = 1
 if s==1 and d==3:
  print('MAX_WEIGHT, MAX_COST, s, d:', MAX_WEIGHT, MAX_COST, s, d)
 my_inf = 10000000
 #min cost to path with t hops s->v : d[v, t]
 dis = []
 par = []
 # vertex set 0, 2, ..., n-1
 n = len(G_cspp.nodes())
 for i in range(0, n):
  dis.append([])
  par.append([])
  #for j in range(0, MAX_HOP*n):
  for j in range(0, MAX_HOP*n):
   if i==s and j==0:
    dis[i].append(0)
    par[i].append(-1)
   else:
    dis[i].append(my_inf)
    par[i].append(-1)
 if s==1 and d==3:
  print(dis)
 m = len(G_cspp.edges())
 #for i=1 to n-1
 for i in range(0, n-1):
  #for t=1 to 10n
  #for t in range(1, MAX_HOP*n):
  for t in range(1, MAX_HOP*n):
   #for (u,v) in E
   for u, v in G_cspp.edges():
    #d[v, t] = min{d[v, t], d[u, t-1]+w(w,v)}
    if dis[v][t] > dis[u][t-1] + G_cspp[u][v]['cost']:
     par[v][t] = u
     dis[v][t] = dis[u][t-1] + G_cspp[u][v]['cost']
    if dis[u][t] > dis[v][t-1] + G_cspp[u][v]['cost']:
     par[u][t] = v
     dis[u][t] = dis[v][t-1] + G_cspp[u][v]['cost']
 if s==1 and d==3:
  print(dis)
  print(par)
 min_i = -1
 cost = -1
 weight = -1
 path_graph = nx.Graph()
 #for i in range(MAX_HOP*n):
 for i in range(MAX_HOP*n):
  #if dis[d][i]<=MAX_COST:
  #if dis[d][i]<MAX_COST:
  if dis[d][i]<MAX_COST+RC_EPS:
  #if (dis[d][i]<MAX_COST) or (dis[d][i]-MAX_COST<RC_EPS) or (MAX_COST-dis[d][i]<RC_EPS):
   #print('dis[d][i]<=MAX_COST')
   curr_cost = dis[d][i]
   curr_weight = 0
   curr_i = i
   curr_node = d
   curr_par = par[d][curr_i]
   temp = nx.Graph()
   while curr_par!=-1:
    temp.add_edge(curr_par, curr_node, weight=G_cspp[curr_par][curr_node]['weight'], cost=G_cspp[curr_par][curr_node]['cost'])
    #print(curr_par, curr_node, G_cspp[curr_par][curr_node]['weight'], G_cspp[curr_par][curr_node]['cost'])
    curr_weight += G_cspp[curr_par][curr_node]['weight']
    curr_i = curr_i - 1
    curr_node = curr_par
    curr_par = par[curr_node][curr_i]
   #print('curr_weight:', curr_weight)
   if curr_weight<=MAX_WEIGHT:
    diff_path = True
    pth = nx.dijkstra_path(temp, s, d)
    for p in init_path_arr[l]:
     matched = path_comparison(p, pth)
     if matched:
      diff_path = False
      break
    if diff_path:
     #if (min_i == -1) or (weight>curr_weight):
     if (min_i == -1) or (cost>curr_cost):
      min_i = i
      cost = curr_cost
      weight = curr_weight
      path_graph = temp
 return (path_graph, cost, weight)

#G, subset_arr = build_networkx_graph('erdos_renyi_sm2/graph_1.txt')
#print('nodes:', G.nodes())
#print('edges:', G.edges())
#for u,v in G.edges():
# print(u, v)

#G = nx.Graph()
#G.add_edge(0, 1, weight=2, cost=1)
#G.add_edge(1, 2, weight=2, cost=1)
#G.add_edge(1, 6, weight=1, cost=2)
#G.add_edge(2, 3, weight=2, cost=1)
#G.add_edge(6, 7, weight=1, cost=2)
#G.add_edge(3, 4, weight=2, cost=1)
#G.add_edge(7, 8, weight=1, cost=2)
#G.add_edge(4, 5, weight=2, cost=1)
#G.add_edge(8, 5, weight=1, cost=2)
#print(bellman_ford(G, 100, 20, 1, 5))


