Time to compute bot up:  0.11464214324951172
Objective value:  91
Time to compute bot up:  1.6922471523284912
Objective value:  131
Time to compute bot up:  12.150012254714966
Objective value:  413
Time to compute bot up:  41.52966046333313
Objective value:  422
Time to compute bot up:  98.1712896823883
Objective value:  568
Time to compute bot up:  0.08048272132873535
Objective value:  46
Time to compute bot up:  1.0759153366088867
Objective value:  102
Time to compute bot up:  8.804336309432983
Objective value:  231
Time to compute bot up:  34.05580282211304
Objective value:  434
Time to compute bot up:  92.02031660079956
Objective value:  391
Time to compute bot up:  0.07147359848022461
Objective value:  45
Time to compute bot up:  0.9422369003295898
Objective value:  66
Time to compute bot up:  6.864544630050659
Objective value:  113
Time to compute bot up:  20.794399738311768
Objective value:  122
Time to compute bot up:  57.64409327507019
Objective value:  260
Time to compute bot up:  0.025632858276367188
Objective value:  34
Time to compute bot up:  0.6326336860656738
Objective value:  65
Time to compute bot up:  3.9750449657440186
Objective value:  98
Time to compute bot up:  14.275949478149414
Objective value:  103
Time to compute bot up:  28.620778560638428
Objective value:  129
Time to compute bot up:  0.22002148628234863
Objective value:  104
Time to compute bot up:  3.0209362506866455
Objective value:  437
Time to compute bot up:  20.598299503326416
Objective value:  601
Time to compute bot up:  58.91523265838623
Objective value:  782
Time to compute bot up:  170.81850242614746
Objective value:  1122
Time to compute bot up:  0.1277601718902588
Objective value:  72
Time to compute bot up:  3.9528558254241943
Objective value:  259
Time to compute bot up:  15.868651390075684
Objective value:  419
Time to compute bot up:  57.270731687545776
Objective value:  553
Time to compute bot up:  109.71417140960693
Objective value:  1008
Time to compute bot up:  0.06380653381347656
Objective value:  53
Time to compute bot up:  1.976529598236084
Objective value:  155
Time to compute bot up:  11.65214490890503
Objective value:  294
Time to compute bot up:  33.79155683517456
Objective value:  382
Time to compute bot up:  88.8550353050232
Objective value:  375
Time to compute bot up:  0.0435633659362793
Objective value:  57
Time to compute bot up:  0.6348741054534912
Objective value:  133
Time to compute bot up:  5.414562225341797
Objective value:  188
Time to compute bot up:  16.782822847366333
Objective value:  226
Time to compute bot up:  60.44303107261658
Objective value:  239
Time to compute bot up:  0.38395261764526367
Objective value:  250
Time to compute bot up:  4.5577239990234375
Objective value:  472
Time to compute bot up:  27.643507719039917
Objective value:  847
Time to compute bot up:  111.66871309280396
Objective value:  1659
Time to compute bot up:  206.59510469436646
Objective value:  1566
Time to compute bot up:  0.21520590782165527
Objective value:  175
Time to compute bot up:  4.140152215957642
Objective value:  423
Time to compute bot up:  24.487597942352295
Objective value:  1084
Time to compute bot up:  86.1196346282959
Objective value:  896
Time to compute bot up:  198.98313856124878
Objective value:  1297
Time to compute bot up:  0.19205570220947266
Objective value:  98
Time to compute bot up:  2.859520435333252
Objective value:  251
Time to compute bot up:  10.843381404876709
Objective value:  355
Time to compute bot up:  50.387452602386475
Objective value:  524
Time to compute bot up:  146.74995756149292
Objective value:  627
Time to compute bot up:  0.07661962509155273
Objective value:  112
Time to compute bot up:  1.2184200286865234
Objective value:  167
Time to compute bot up:  7.028470277786255
Objective value:  261
Time to compute bot up:  29.03670024871826
Objective value:  472
Time to compute bot up:  88.06323552131653
Objective value:  462
