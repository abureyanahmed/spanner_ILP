Time to compute bot up:  0.19205570220947266
Objective value:  98
Time to compute bot up:  2.859520435333252
Objective value:  251
Time to compute bot up:  10.843381404876709
Objective value:  355
Time to compute bot up:  50.387452602386475
Objective value:  524
Time to compute bot up:  146.74995756149292
Objective value:  627
Time to compute bot up:  0.07661962509155273
Objective value:  112
Time to compute bot up:  1.2184200286865234
Objective value:  167
Time to compute bot up:  7.028470277786255
Objective value:  261
Time to compute bot up:  29.03670024871826
Objective value:  472
Time to compute bot up:  88.06323552131653
Objective value:  462
