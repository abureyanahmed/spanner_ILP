Time to compute bot up:  0.06492924690246582
Objective value:  55.0
Time to compute bot up:  2.0843148231506348
Objective value:  241.0
Time to compute bot up:  13.835218667984009
Objective value:  423.0
Time to compute bot up:  32.22089099884033
Objective value:  327.0
Time to compute bot up:  0.09968924522399902
Objective value:  42.0
Time to compute bot up:  1.6553616523742676
Objective value:  83.0
Time to compute bot up:  8.733568668365479
Objective value:  225.0
Time to compute bot up:  27.826776027679443
Objective value:  327.0
Time to compute bot up:  0.05337214469909668
Objective value:  21.0
Time to compute bot up:  1.3139400482177734
Objective value:  116.0
Time to compute bot up:  6.4609339237213135
Objective value:  152.0
Time to compute bot up:  22.242592573165894
Objective value:  154.0
Time to compute bot up:  0.03863525390625
Objective value:  24.0
Time to compute bot up:  0.6841452121734619
Objective value:  56.0
Time to compute bot up:  3.319520950317383
Objective value:  88.0
Time to compute bot up:  9.857155561447144
Objective value:  98.0
Time to compute bot up:  0.11976933479309082
Objective value:  99.0
Time to compute bot up:  2.95052170753479
Objective value:  327.0
Time to compute bot up:  15.177325010299683
Objective value:  683.0
Time to compute bot up:  59.31731557846069
Objective value:  827.0
Time to compute bot up:  0.1283104419708252
Objective value:  132.0
Time to compute bot up:  2.0788931846618652
Objective value:  217.0
Time to compute bot up:  15.721040487289429
Objective value:  438.0
Time to compute bot up:  55.308988094329834
Objective value:  572.0
Time to compute bot up:  0.12892651557922363
Objective value:  73.0
Time to compute bot up:  1.8199920654296875
Objective value:  136.0
Time to compute bot up:  10.634739875793457
Objective value:  242.0
Time to compute bot up:  43.536964416503906
Objective value:  349.0
Time to compute bot up:  0.07607889175415039
Objective value:  61.0
Time to compute bot up:  1.1693942546844482
Objective value:  135.0
Time to compute bot up:  4.926616907119751
Objective value:  155.0
Time to compute bot up:  19.575222492218018
Objective value:  201.0
Time to compute bot up:  0.211836576461792
Objective value:  174.0
Time to compute bot up:  6.200114727020264
Objective value:  703.0
Time to compute bot up:  26.567920446395874
Objective value:  1045.0
Time to compute bot up:  90.62282156944275
Objective value:  1085.0
Time to compute bot up:  0.25774097442626953
Objective value:  279.0
Time to compute bot up:  5.168612003326416
Objective value:  452.0
Time to compute bot up:  20.271188735961914
Objective value:  525.0
Time to compute bot up:  76.73989796638489
Objective value:  946.0
Time to compute bot up:  0.06792163848876953
Objective value:  143.0
Time to compute bot up:  2.503661870956421
Objective value:  176.0
Time to compute bot up:  13.134985208511353
Objective value:  481.0
Time to compute bot up:  52.83593130111694
Objective value:  393.0
Time to compute bot up:  0.10271954536437988
Objective value:  100.0
Time to compute bot up:  1.7707269191741943
Objective value:  208.0
Time to compute bot up:  9.534789562225342
Objective value:  203.0
Time to compute bot up:  27.75061821937561
Objective value:  350.0
