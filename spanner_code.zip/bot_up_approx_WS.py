Time to compute bot up:  0.10644865036010742
Objective value:  63
Time to compute bot up:  1.3642563819885254
Objective value:  131
Time to compute bot up:  6.7019593715667725
Objective value:  348
Time to compute bot up:  26.321233987808228
Objective value:  412
Time to compute bot up:  52.85281157493591
Objective value:  376
Time to compute bot up:  0.0835108757019043
Objective value:  39
Time to compute bot up:  1.0968384742736816
Objective value:  62
Time to compute bot up:  5.375626802444458
Objective value:  185
Time to compute bot up:  19.197501182556152
Objective value:  341
Time to compute bot up:  55.50999617576599
Objective value:  424
Time to compute bot up:  0.06630992889404297
Objective value:  32
Time to compute bot up:  1.0030603408813477
Objective value:  101
Time to compute bot up:  5.014093399047852
Objective value:  135
Time to compute bot up:  18.31161141395569
Objective value:  171
Time to compute bot up:  40.90249800682068
Objective value:  190
Time to compute bot up:  0.04064464569091797
Objective value:  28
Time to compute bot up:  0.5384316444396973
Objective value:  77
Time to compute bot up:  3.4469408988952637
Objective value:  125
Time to compute bot up:  11.890310049057007
Objective value:  127
Time to compute bot up:  34.563613176345825
Objective value:  167
Time to compute bot up:  0.13759422302246094
Objective value:  143
Time to compute bot up:  2.384115695953369
Objective value:  186
Time to compute bot up:  12.151966333389282
Objective value:  451
Time to compute bot up:  38.645832777023315
Objective value:  770
Time to compute bot up:  88.33168005943298
Objective value:  769
Time to compute bot up:  0.13973093032836914
Objective value:  111
Time to compute bot up:  2.4618725776672363
Objective value:  193
Time to compute bot up:  10.193591356277466
Objective value:  403
Time to compute bot up:  35.54937171936035
Objective value:  544
Time to compute bot up:  100.22721028327942
Objective value:  889
Time to compute bot up:  0.0971825122833252
Objective value:  68
Time to compute bot up:  2.154614210128784
Objective value:  202
Time to compute bot up:  8.69582724571228
Objective value:  307
Time to compute bot up:  30.13257622718811
Objective value:  385
Time to compute bot up:  78.91752624511719
Objective value:  430
Time to compute bot up:  0.06952905654907227
Objective value:  63
Time to compute bot up:  1.17744779586792
Objective value:  146
Time to compute bot up:  5.75779128074646
Objective value:  176
Time to compute bot up:  23.63652229309082
Objective value:  236
Time to compute bot up:  50.88375973701477
Objective value:  308
Time to compute bot up:  0.2084977626800537
Objective value:  209
Time to compute bot up:  4.029405117034912
Objective value:  476
Time to compute bot up:  12.737150430679321
Objective value:  841
Time to compute bot up:  59.32520031929016
Objective value:  1111
Time to compute bot up:  118.34131169319153
Objective value:  1491
Time to compute bot up:  0.1865551471710205
Objective value:  111
Time to compute bot up:  3.508044481277466
Objective value:  448
Time to compute bot up:  16.50982141494751
Objective value:  548
Time to compute bot up:  57.86040949821472
Objective value:  825
Time to compute bot up:  134.63724780082703
Objective value:  1193
Time to compute bot up:  0.1273186206817627
Objective value:  112
Time to compute bot up:  2.4219603538513184
Objective value:  236
Time to compute bot up:  13.618131875991821
Objective value:  423
Time to compute bot up:  42.42759442329407
Objective value:  573
Time to compute bot up:  124.71989178657532
Objective value:  768
Time to compute bot up:  0.09669113159179688
Objective value:  76
Time to compute bot up:  1.424440622329712
Objective value:  166
Time to compute bot up:  9.216085433959961
Objective value:  267
Time to compute bot up:  29.422793865203857
Objective value:  315
Time to compute bot up:  75.95728754997253
Objective value:  571
