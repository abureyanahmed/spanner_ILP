Time to compute bot up: 145.96029615402222
Objective value: 910
Time to compute bot up: 131.06950449943542
Objective value: 680
Time to compute bot up: 99.45526623725891
Objective value: 345
Time to compute bot up: 63.12108039855957
Objective value: 237
Time to compute bot up: 245.13245058059692
Objective value: 1868
Time to compute bot up: 216.79207611083984
Objective value: 1368
Time to compute bot up: 170.78734469413757
Objective value: 740
Time to compute bot up: 112.06647849082947
Objective value: 507
Time to compute bot up: 326.4104504585266
Objective value: 2694
Time to compute bot up: 286.13326120376587
Objective value: 2008
Time to compute bot up: 227.78611397743225
Objective value: 1072
Time to compute bot up: 150.04487133026123
Objective value: 727
Time to compute bot up: 407.2619957923889
Objective value: 3603
Time to compute bot up: 356.45400190353394
Objective value: 2659
Time to compute bot up: 275.69792795181274
Objective value: 1399
Time to compute bot up: 191.22752404212952
Objective value: 964
Time to compute bot up: 481.21894931793213
Objective value: 4490
Time to compute bot up: 424.7640790939331
Objective value: 3322
Time to compute bot up: 332.03657841682434
Objective value: 1743
Time to compute bot up: 231.78802251815796
Objective value: 1163
Time to compute bot up: 3134.8414912223816
Objective value: 3021
Time to compute bot up: 3088.674179792404
Objective value: 2240
Time to compute bot up: 2185.640279531479
Objective value: 1137
Time to compute bot up: 1181.9606177806854
Objective value: 629
Time to compute bot up: 5470.795719861984
Objective value: 6019
Time to compute bot up: 5324.704210758209
Objective value: 4445
Time to compute bot up: 3776.7717933654785
Objective value: 2317
Time to compute bot up: 2056.3783326148987
Objective value: 1290
Time to compute bot up: 7321.004450798035
Objective value: 8990
Time to compute bot up: 7437.477706193924
Objective value: 6658
Time to compute bot up: 5531.95400762558
Objective value: 3492
Time to compute bot up: 2831.5424456596375
Objective value: 1916
Time to compute bot up: 9614.728547096252
Objective value: 11891
Time to compute bot up: 9482.300482749939
Objective value: 8851
Time to compute bot up: 6794.646137714386
Objective value: 4620
Time to compute bot up: 3689.2053945064545
Objective value: 2549
Time to compute bot up: 11451.738419771194
Objective value: 14748
Time to compute bot up: 11214.548610687256
Objective value: 11020
Time to compute bot up: 8096.444898366928
Objective value: 5765
Time to compute bot up: 4070.63343834877
Objective value: 3163
Time to compute bot up: 22117.88808131218
Objective value: 5053
Time to compute bot up: 19080.730954170227
Objective value: 3719
Time to compute bot up: 12129.731322288513
Objective value: 1631
