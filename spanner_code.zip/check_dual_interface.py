import sys
sys.path.append('/cm/shared/uaapps/cplex/12.7.1/cplex/python/3.5/x86-64_linux/')
import cplex
from cplex.exceptions import CplexError
import time
import math
from input_functions import *
from collections import defaultdict
import cspp
from bellman_ford import *

def vertex_cover_ilp():
  my_inf = 1000000

  # initialize
  obj = list()
  sense = ""
  rownames = list()
  total_rows = 0
  colnames = list()
  total_columns = 0
  ub = list()
  lb = list()
  get_column = dict()
  ctype = list()

  rows = []
  cols = []
  vals = []

  constraint_values = []

  vertices = [0, 1, 2]
  for v in vertices:
    obj.append(1)
    var_name = 'v_'+str(v)
    colnames.append(var_name)
    get_column[var_name] = total_columns
    total_columns = total_columns + 1

  edges = [[0, 1], [1, 2], [0, 2]]
  for i in range(len(edges)):
    u = edges[i][0]
    v = edges[i][1]
    rownames.append('e_'+str(u)+'_'+str(v))
    constraint_values.append(1)
    sense = sense + 'G'
    rows.append(total_rows)
    cols.append(get_column['v_'+str(u)])
    vals.append(1)
    rows.append(total_rows)
    cols.append(get_column['v_'+str(v)])
    vals.append(1)
    total_rows = total_rows + 1

  for i in range(len(obj)):
    #init_prim_ub.append(cplex.infinity)
    ub.append(1.0)
    lb.append(0.0)

    ctype.append(cplex.Cplex().variables.type.continuous)

  prob = cplex.Cplex()
  prob.objective.set_sense(prob.objective.sense.minimize)
  prob.linear_constraints.add(rhs = constraint_values, senses = sense, names = rownames)
  prob.variables.add(obj = obj, ub = ub, lb = lb, names = colnames)

  name_indices = [i for i in range(len(obj))]
  names = prob.variables.get_names(name_indices)

  prob.linear_constraints.set_coefficients(zip(rows, cols, vals))
  prob.solve()
  print("Solution value  = ", prob.solution.get_objective_value())
  numcols = prob.variables.get_num()
  x = prob.solution.get_values()
  for j in range(numcols):
    print("Column %s:  Value = %10f" % (names[j], x[j]))
  x = prob.solution.get_values()
  print('Dual values:', x)

vertex_cover_ilp()


