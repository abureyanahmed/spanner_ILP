import matplotlib
import matplotlib.pyplot as plt
from ilp_checker_lib import *
import sys

obj_values = get_values(sys.argv[1], 'objective value: ')

plt.plot(range(len(obj_values)), obj_values, 'r--')
plt.xlabel('Number of iterations', fontsize=20)
plt.ylabel('Objective value', fontsize=20)
#plt.ylim(1,max_label)
#plt.ylim(.94,1.8)
#plt.ylim(.94,1.9)
#plt.legend(['max', 'avg', 'min'], loc='upper right', fontsize=16)
plt.tick_params(axis='x', labelsize=16)
plt.tick_params(axis='y', labelsize=16)
plt.show()
#plt.savefig(path_to_plots_directory+name_of_graph_class[cl]+'_'+str(number_of_nodes_progression[0])+'_NVT.png', bbox_inches='tight')
#plt.close()


