import os

def write_input_files():
 root_folder = "experiment_1"
 f = open(root_folder + '/' + 'id_to_file.csv')
 curr_id = 1
 file_names = []
 for name in os.listdir(folder_name):
  if name[len(name)-4:len(name)]=='.txt':
   file_names.append(name[:len(name)-4])

write_input_files()

