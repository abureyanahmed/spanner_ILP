import networkx as nx
from heap_obj import *

def path_comparison(p, sub_pth):
  if len(p)!=len(sub_pth):
    return False
  matched = True
  for j in range(len(p)):
    if not p[j] == sub_pth[j]:
      matched = False
  if not matched:
    matched = True
    for j in range(len(p)):
      t = len(p)-j-1
      if not p[t] == sub_pth[j]:
        matched = False
  return matched

def main(G, MAX_WEIGHT, MAX_COST, sourceNode, destNode, init_path_arr, l):

	RC_EPS = 1.0e-6
	res = find_shortes_path_tree(G, destNode, 'weight')
	T_w = dict()
	for node in res:
		T_w[node.n] = node.v
	res = find_shortes_path_tree(G, destNode, 'cost')
	T_c = dict()
	for node in res:
		T_c[node.n] = node.v
	h = Heap()
	h.insert(Node(sourceNode, 0, 0, -1, [sourceNode]))
	while not h.is_empty():
		m = h.pop()
		if m.n == destNode:
			cost = 0
			wgt = 0
			temp = nx.Graph()
			pth = m.pth
			for i in range(1, len(pth)):
				u = pth[i-1]
				v = pth[i]
				temp.add_edge(u, v, weight=G[u][v]['weight'], cost=G[u][v]['cost'])
				cost += G[u][v]['cost']
				wgt += G[u][v]['weight']
			diff_path = True
			for p in init_path_arr[l]:
				matched = path_comparison(p, pth)
				if matched:
					diff_path = False
					break
			if diff_path:
				#print(pth)
				return (temp, cost, wgt)
		for nbr in G[m.n]:
			if nbr not in m.pth:
				if m.v2+G[m.n][nbr]['cost']+T_c[nbr]<MAX_COST+RC_EPS and m.v+G[m.n][nbr]['weight']+T_w[nbr]<=MAX_WEIGHT:
					pth2 = m.pth[:]
					pth2.append(nbr)
					h.insert(Node(nbr, m.v+G[m.n][nbr]['weight'], m.v2+G[m.n][nbr]['cost'], m.n, pth2))
	return (nx.Graph(), -1, -1)

#G = nx.Graph()
#G.add_edge(0, 1, weight=2, cost=1)
#G.add_edge(1, 2, weight=2, cost=1)
#G.add_edge(1, 6, weight=1, cost=2)
#G.add_edge(2, 3, weight=2, cost=1)
#G.add_edge(6, 7, weight=1, cost=2)
#G.add_edge(3, 4, weight=2, cost=1)
#G.add_edge(7, 8, weight=1, cost=2)
#G.add_edge(4, 5, weight=2, cost=1)
#G.add_edge(8, 5, weight=1, cost=2)
#print(main(G, 10, 10, 0, 1, [[[0,5], [2, 3]]], 0))

#G = nx.Graph()
#G.add_edge(0, 1, weight=10, cost=10)
#G.add_edge(0, 3, weight=8, cost=0)
#G.add_edge(1, 2, weight=6, cost=0)
#G.add_edge(1, 3, weight=8, cost=0)
#G.add_edge(2, 3, weight=4, cost=0)
#print(main(G, 24, 0, 0, 2, [[[0,1], [0, 3, 2], [0, 3], [3, 2], [1, 2], [1, 3]]], 0))

