#run_test = True
run_test = False

from collections import defaultdict

class Node:
 def __init__(self, node, value, value2, parent, path):
  self.n = node
  self.v = value
  self.v2 = value2
  self.p = parent
  self.pth = path
 def print_node(self):
  print("node: ", self.n, ", value: ", self.v, ", value2: ", self.v2, ", parent: ", self.p, ", path: ", self.pth)

def is_a_less_than_b(a, b):
 return a.v<b.v

class Heap:
 def __init__(self):
  self.arr = [0]
  self.size = 0

 def print_heap(self):
  for i in self.arr:
   if i!=0:
    i.print_node()

 def perc_up(self, i):
  while i // 2 >0:
   if is_a_less_than_b(self.arr[i], self.arr[i//2]):
    t = self.arr[i]
    self.arr[i] = self.arr[i//2]
    self.arr[i//2] = t
   i = i//2

 def insert(self, num):
  self.arr.append(num)
  self.size += 1
  self.perc_up(self.size)

 def get_min_child(self, i):
  if 2*i + 1 > self.size:
   return 2*i
  else:
   if is_a_less_than_b(self.arr[2*i], self.arr[2*i+1]):
    return 2*i
   else:
    return 2*i + 1

 def perc_down(self, i):
  while 2*i <= self.size:
   mc = self.get_min_child(i)
   if is_a_less_than_b(self.arr[mc], self.arr[i]):
    t = self.arr[mc]
    self.arr[mc] = self.arr[i]
    self.arr[i] = t
   i = mc

 def pop(self):
  mn = self.arr[1]
  self.arr[1] = self.arr[self.size]
  self.size -= 1
  self.arr.pop()
  self.perc_down(1)
  return mn

 def is_empty(self):
  if self.size ==0:
   return True
  return False
    

def find_shortes_path_tree(G, t, prop):
 h = Heap()
 h.insert(Node(t, 0, 0, -1, [t]))
 explored = set()
 res = []
 while not h.is_empty():
  m = h.pop()
  if m.n not in explored:
   explored.add(m.n)
   #m.print_node()
   res.append(m)
   for nbr in G[m.n]:
    pth2 = m.pth[:]
    pth2.append(nbr)
    h.insert(Node(nbr, m.v+G[m.n][nbr][prop], 0, m.n, pth2))
 return res

def test_shortes_path_tree():
 import networkx as nx
 G = nx.DiGraph()
 G.add_edges_from([(11, 7, {'weight':7})])
 G.add_edges_from([(11, 10, {'weight':11})])
 G.add_edges_from([(10, 6, {'weight':12})])
 G.add_edges_from([(10, 9, {'weight':8})])
 G.add_edges_from([(9, 5, {'weight':20})])
 G.add_edges_from([(9, 8, {'weight':18})])
 G.add_edges_from([(8, 4, {'weight':15})])
 G.add_edges_from([(7, 3, {'weight':15})])
 G.add_edges_from([(7, 6, {'weight':25})])
 G.add_edges_from([(6, 2, {'weight':14})])
 G.add_edges_from([(6, 5, {'weight':10})])
 G.add_edges_from([(5, 1, {'weight':27})])
 G.add_edges_from([(5, 4, {'weight':9})])
 G.add_edges_from([(4, 0, {'weight':13})])
 G.add_edges_from([(3, 2, {'weight':14})])
 G.add_edges_from([(2, 1, {'weight':20})])
 G.add_edges_from([(1, 0, {'weight':2})])

 res = find_shortes_path_tree(G, 11, 'weight')

 org_res = [
  Node(11 , 0 , 0, -1, []),
  Node(7 , 7 , 0, 11, []),
  Node(10 , 11 , 0, 11, []),
  Node(9 , 19 , 0, 10, []),
  Node(3 , 22 , 0, 7, []),
  Node(6 , 23 , 0, 10, []),
  Node(5 , 33 , 0, 6, []),
  Node(2 , 36 , 0, 3, []),
  Node(8 , 37 , 0, 9, []),
  Node(4 , 42 , 0, 5, []),
  Node(0 , 55 , 0, 4, []),
  Node(1 , 56 , 0, 2, [])
 ]
 for x in res:
  for y in org_res:
    if x.n == y.n:
     if (x.v != y.v) or (x.v2 != y.v2) or (x.p != y.p):
      print('Test case failed.')
 print('Test case ended.')


if run_test:
 test_shortes_path_tree()


