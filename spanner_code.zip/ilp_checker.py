import sys
from ilp_checker_lib import *

log_file_name = sys.argv[1]
sum_lp_time = check_time(log_file_name, 'Time for lp: ')
print('sum_lp_time:', sum_lp_time, ' seconds')
print('sum_lp_time:', sum_lp_time/60, ' minutes')
sum_add_pth_time = check_time(log_file_name, 'Time for add path: ')
print('sum_add_pth_time:', sum_add_pth_time, ' seconds')
print('sum_add_pth_time:', sum_add_pth_time/60, ' minutes')
sum_cspp_time = check_time(log_file_name, 'Time for cspp: ')
print('sum_cspp_time:', sum_cspp_time, ' seconds')
print('sum_cspp_time:', sum_cspp_time/60, ' minutes')
print('total time:', (sum_lp_time + sum_add_pth_time), ' seconds')
print('total time:', (sum_lp_time + sum_add_pth_time)/60, ' minutes')
#check_dual('erdos_renyi_mid/print_log.txt', 'dual_vals: ')

