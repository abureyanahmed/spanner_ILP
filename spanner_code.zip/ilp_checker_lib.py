def check_time(file_name, split_str):
 f = open(file_name)
 s = f.read()
 arr = s.split(split_str)
 arr = arr[1:]
 sum_lp_time = 0
 for e in arr:
  e = e.split()[0]
  sum_lp_time += float(e)
 return sum_lp_time

def get_values(file_name, split_str):
 f = open(file_name)
 s = f.read()
 arr = s.split(split_str)
 arr = arr[1:]
 results = []
 for e in arr:
  e = e.split()[0]
  results.append(float(e))
 return results

def check_dual(file_name, split_str):
 f = open(file_name)
 s = f.read()
 arr = s.split(split_str)
 arr = arr[1:]
 for e in arr:
  e = e.strip().split(']')[0].strip().split('[')[1].split(',')
  sum_d = 0
  for t in e:
   sum_d += float(t)
  print('dual sum:', sum_d)


