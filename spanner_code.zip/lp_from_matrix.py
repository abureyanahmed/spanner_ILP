import sys
sys.path.append('/cm/shared/uaapps/cplex/12.7.1/cplex/python/3.5/x86-64_linux/')
import cplex
from cplex.exceptions import CplexError

def run_cplex(obj, constraint_values, sense, rownames, colnames, ub, lb, ctype, rows, cols, vals, model_file):
  prob = cplex.Cplex()
  #prob.objective.set_sense(prob.objective.sense.minimize)
  prob.objective.set_sense(prob.objective.sense.maximize)
  prob.linear_constraints.add(rhs = constraint_values, senses = sense, names = rownames)
  prob.variables.add(obj = obj, ub = ub, lb = lb, types=ctype, names = colnames)

  name_indices = [i for i in range(len(obj))]
  names = prob.variables.get_names(name_indices)

  prob.linear_constraints.set_coefficients(zip(rows, cols, vals))
  prob.write(model_file)
  prob.solve()
  print("Solution value  = ", prob.solution.get_objective_value())
  numcols = prob.variables.get_num()
  x = prob.solution.get_values()
  for j in range(numcols):
    print("Column %s:  Value = %10f" % (names[j], x[j]))
  return names, x

#obj = [0, 0, 0, 0, 1, 1, 1]
#sense = "LLLLL"
#rownames = ['r_'+str(i) for i in range(len(sense))]
#colnames = ['pi_0_1_e_0_1_0', 'pi_0_2_e_0_1_0', 'pi_0_2_e_1_2_0', 'pi_1_2_e_1_2_0', 'sigma_0_1_0', 'sigma_0_2_0', 'sigma_1_2_0']
#ub = [100 for i in range(len(colnames))]
#lb = [0 for i in range(len(colnames))]
#ctype = [cplex.Cplex().variables.type.continuous for i in range(len(colnames))]

#rows = [0, 0, 1, 1, 2, 2, 3, 3, 3, 4, 4]
#cols = [0, 1, 2, 3, 0, 4, 2, 1, 5, 3, 6]
#vals = [1, 1, 1, 1, -1, 1, -1, -1, 1, -1, 1]

#constraint_values = [6, 6, 0, 0, 0]

#model_file = 'something.lp'

obj = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1]
sense = "LLLLLLLLLLLLLL"
rownames = ['r_'+str(i) for i in range(len(sense))]
colnames = ['pi_0_1_e_0_1_0', 'pi_0_1_e_0_3_0', 'pi_0_1_e_1_3_0', 'pi_0_2_e_0_1_0', 'pi_0_2_e_0_3_0', 'pi_0_2_e_1_2_0', 'pi_0_2_e_2_3_0', 'pi_0_3_e_0_3_0', 'pi_1_2_e_1_2_0', 'pi_1_2_e_1_3_0', 'pi_1_2_e_2_3_0', 'pi_1_3_e_1_3_0', 'pi_2_3_e_2_3_0', 'sigma_0_1_0', 'sigma_0_2_0', 'sigma_0_3_0', 'sigma_1_2_0', 'sigma_1_3_0', 'sigma_2_3_0']
ub = [100 for i in range(len(colnames))]
lb = [0 for i in range(len(colnames))]
ctype = [cplex.Cplex().variables.type.continuous for i in range(len(colnames))]

rows = [0, 0, 1, 1, 1, 2, 2, 3, 3, 3, 4, 4, 4, 5, 5, 6, 6, 6, 7, 7, 7, 8, 8, 8, 9, 9, 10, 10, 11, 11, 11, 12, 12, 13, 13]
cols = [0, 3, 1, 4, 7, 5, 8, 2, 9, 11, 6, 10, 12, 0, 13, 1, 2, 13, 4, 6, 14, 3, 5, 14, 7, 15, 8, 16, 9, 10, 16, 11, 17, 12, 18]
vals = [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, -1, 1, -1, -1, 1, -1, -1, 1, -1, -1, 1, -1, 1, -1, 1, -1, -1, 1, -1, 1, -1, 1]

#constraint_values = [10, 8, 6, 8, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0]
constraint_values = [10.01, 6.02, 4.04, 8.08, 8.17, 0, 0, 0, 0, 0, 0, 0, 0, 0]

model_file = 'something.lp'

#get_column = dict()
#total_columns = 0
#obj = []
#edges = [['0','1'], ['1', '2'], ['2', '3'], ['0', '3'], ['1', '3']]
##wgt = [10, 6, 4, 8, 8]
#wgt = [10.01, 6.02, 4.04, 8.08, 8.17]
#pairs = [['0', '1'], ['0', '2'], ['0', '3'], ['1', '2'], ['1', '3'], ['2', '3']]
#pths = [[[0,1], [0, 3, 1], [0, 3, 2, 1]], 
#  [[0, 3, 2], [0, 1, 2], [0, 3, 1, 2], [0, 1, 3, 2]], 
#  [[0, 3]], 
#  [[1, 2], [1, 3, 2]], 
#  [[1, 3], [1, 2, 3]], 
#  [[2, 3]]]
#colnames = []
#for p in pairs:
#  p = p[0] + '_' + p[1]
#  for e in edges:
#    e = e[0] + '_' + e[1]
#    var_name = 'pi_'+ p + '_e_' + e + '_0'
#    colnames.append(var_name)
#    obj.append(0)
#    get_column[var_name] = total_columns
#    total_columns = total_columns + 1
#  var_name = 'sigma_' + p + '_0'
#  colnames.append(var_name)
#  obj.append(1)
#  get_column[var_name] = total_columns
#  total_columns = total_columns + 1
#ub = [100 for i in range(len(colnames))]
#lb = [0 for i in range(len(colnames))]
#ctype = [cplex.Cplex().variables.type.continuous for i in range(len(colnames))]

#print(colnames, ctype)

#total_rows = 0
#rows = []
#cols = []
#vals = []
#sense = ""

#constraint_values = []

#i = 0
#for e in edges:
#  sense += "L"
#  constraint_values.append(wgt[i])
#  i += 1
#  e = e[0] + '_' + e[1]
#  for p in pairs:
#    p = p[0] + '_' + p[1]
#    var_name = 'pi_'+ p + '_e_' + e + '_0'
#    rows.append(total_rows)
#    cols.append(get_column[var_name])
#    vals.append(1)
#  total_rows += 1

#for i in range(len(pairs)):
#  p = pairs[i]
#  p = p[0] + '_' + p[1]
#  for pth in pths[i]:
#    sense += "L"
#    constraint_values.append(0)
#    for j in range(len(pth)-1):
#      u = pth[j]
#      v = pth[j+1]
#      if u>v:
#        t = u
#        u = v
#        v = t
#      var_name = 'pi_'+ p + '_e_' + str(u) + '_' + str(v) + '_0'
#      rows.append(total_rows)
#      cols.append(get_column[var_name])
#      vals.append(-1)
#    var_name = 'sigma_' + p + '_0'
#    rows.append(total_rows)
#    cols.append(get_column[var_name])
#    vals.append(1)
#    total_rows += 1

#rownames = ['r_'+str(i) for i in range(len(sense))]
#model_file = 'something.lp'

run_cplex(obj, constraint_values, sense, rownames, colnames, ub, lb, ctype, rows, cols, vals, model_file)


