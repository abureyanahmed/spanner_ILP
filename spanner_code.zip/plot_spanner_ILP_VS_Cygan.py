import sys
if len(sys.argv)<7:
 print('usage:python plot_spanner_ILP_VS_Cygan.py spanner_scores_ER.js output.txt plot_file_name.png leg1 leg2 title')
 quit()

def read_socre_file(f_name):
 steiner_scores = []
 f = open(f_name)
 tmp_arr = f.readline().split('[')[1].split(']')[0].split(',')
 for i in range(len(tmp_arr)):
  steiner_scores.append(tmp_arr[i])
 f.close()
 return steiner_scores

def read_txt_file(f_name):
	num_vertices = []
	E_G = []
	E_S = []
	n_r_s = []
	subset_size = []
	file = open(f_name, "r") 
	first = True
	for line in file:
		if(first):
			first = False
		else:
			arr = line.split(";")
			num_vertices.append(int(arr[0]))
			E_G.append(arr[1])
			subset_size.append(int(arr[2]))
			E_S.append(arr[3])
			n_r_s.append(arr[4])
	for i in range(1,len(subset_size)):
		for j in range(len(subset_size)-i):
			if subset_size[j]>subset_size[j+1]:
				tmp = subset_size[j]
				subset_size[j] = subset_size[j+1]
				subset_size[j+1] = tmp
				tmp = E_G[j]
				E_G[j] = E_G[j+1]
				E_G[j+1] = tmp
				tmp = E_S[j]
				E_S[j] = E_S[j+1]
				E_S[j+1] = tmp
				tmp = n_r_s[j]
				n_r_s[j] = n_r_s[j+1]
				n_r_s[j+1] = tmp
	file.close()
	return subset_size, E_G, E_S

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

plt.figure()
exact_scores = read_socre_file(sys.argv[1])
subset_size, E_G, E_S = read_txt_file(sys.argv[2])
size = min(len(exact_scores), len(subset_size))
init_nodes = 2
for i in range(size):
 plt.plot(range(init_nodes,init_nodes+size), exact_scores[0:size], 'r--', range(init_nodes,init_nodes+size), E_S[0:size], 'b--', range(init_nodes,init_nodes+size), E_G[0:size], 'g--')
 plt.xlabel('Subset size', fontsize=20)
 plt.ylabel('Edges', fontsize=20)
 #plt.ylim(1,max_label)
 #plt.ylim(.94,1.8)
 plt.legend([sys.argv[4], sys.argv[5], 'Graph edges'], loc='upper right')
 plt.title(sys.argv[6])
 plt.show()
 plt.savefig(sys.argv[3], bbox_inches='tight')
 plt.close()
