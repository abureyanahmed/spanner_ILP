Time to compute top down:  0.032315731048583984
Objective value:  91
Time to compute top down:  0.6948211193084717
Objective value:  139
Time to compute top down:  6.223410129547119
Objective value:  428
Time to compute top down:  11.045754194259644
Objective value:  426
Time to compute top down:  26.292475938796997
Objective value:  569
Time to compute top down:  0.02727198600769043
Objective value:  46
Time to compute top down:  0.4917736053466797
Objective value:  122
Time to compute top down:  3.9278647899627686
Objective value:  228
Time to compute top down:  16.61031484603882
Objective value:  441
Time to compute top down:  32.81369948387146
Objective value:  393
Time to compute top down:  0.023981332778930664
Objective value:  46
Time to compute top down:  0.13512945175170898
Objective value:  66
Time to compute top down:  2.4491662979125977
Objective value:  109
Time to compute top down:  5.244009256362915
Objective value:  120
Time to compute top down:  21.884348154067993
Objective value:  264
Time to compute top down:  0.0070648193359375
Objective value:  32
Time to compute top down:  0.13152384757995605
Objective value:  52
Time to compute top down:  0.781313419342041
Objective value:  84
Time to compute top down:  2.4215245246887207
Objective value:  107
Time to compute top down:  9.225671529769897
Objective value:  128
Time to compute top down:  0.04526090621948242
Objective value:  104
Time to compute top down:  1.5808725357055664
Objective value:  435
Time to compute top down:  11.183887243270874
Objective value:  615
Time to compute top down:  32.00006628036499
Objective value:  780
Time to compute top down:  90.59268426895142
Objective value:  1127
Time to compute top down:  0.05822634696960449
Objective value:  72
Time to compute top down:  1.736330270767212
Objective value:  255
Time to compute top down:  9.017449378967285
Objective value:  427
Time to compute top down:  27.668267488479614
Objective value:  567
Time to compute top down:  69.62563824653625
Objective value:  1009
Time to compute top down:  0.030511140823364258
Objective value:  53
Time to compute top down:  0.752089262008667
Objective value:  157
Time to compute top down:  7.733241081237793
Objective value:  297
Time to compute top down:  19.59639310836792
Objective value:  394
Time to compute top down:  67.76311993598938
Objective value:  390
Time to compute top down:  0.02888321876525879
Objective value:  58
Time to compute top down:  0.5897185802459717
Objective value:  133
Time to compute top down:  3.863046169281006
Objective value:  174
Time to compute top down:  7.600273132324219
Objective value:  225
Time to compute top down:  17.500154972076416
Objective value:  216
Time to compute top down:  0.1647050380706787
Objective value:  255
Time to compute top down:  2.5838615894317627
Objective value:  471
Time to compute top down:  16.948708057403564
Objective value:  861
Time to compute top down:  68.16719913482666
Objective value:  1685
Time to compute top down:  123.03833770751953
Objective value:  1555
Time to compute top down:  0.11913037300109863
Objective value:  175
Time to compute top down:  2.1139042377471924
Objective value:  444
Time to compute top down:  15.844897270202637
Objective value:  1167
Time to compute top down:  42.15705370903015
Objective value:  903
Time to compute top down:  118.47517561912537
Objective value:  1313
Time to compute top down:  0.08543634414672852
Objective value:  94
Time to compute top down:  1.6842327117919922
Objective value:  249
Time to compute top down:  7.899662256240845
Objective value:  353
Time to compute top down:  29.59004807472229
Objective value:  532
Time to compute top down:  96.34219908714294
Objective value:  658
Time to compute top down:  0.053786277770996094
Objective value:  106
Time to compute top down:  0.6429486274719238
Objective value:  158
Time to compute top down:  6.245616912841797
Objective value:  273
Time to compute top down:  23.25882840156555
Objective value:  396
Time to compute top down:  58.905468463897705
Objective value:  444
