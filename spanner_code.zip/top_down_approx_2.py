Time to compute top down:  0.048383474349975586
Objective value:  55.0
Time to compute top down:  0.7691547870635986
Objective value:  244.0
Time to compute top down:  5.181074142456055
Objective value:  423.0
Time to compute top down:  10.425813436508179
Objective value:  328.0
Time to compute top down:  0.020910263061523438
Objective value:  42.0
Time to compute top down:  0.42334604263305664
Objective value:  80.0
Time to compute top down:  3.3891193866729736
Objective value:  226.0
Time to compute top down:  8.873498678207397
Objective value:  332.0
Time to compute top down:  0.01627969741821289
Objective value:  21.0
Time to compute top down:  0.3815767765045166
Objective value:  105.0
Time to compute top down:  1.7551720142364502
Objective value:  158.0
Time to compute top down:  8.882732629776001
Objective value:  167.0
Time to compute top down:  0.007274150848388672
Objective value:  24.0
Time to compute top down:  0.05879545211791992
Objective value:  54.0
Time to compute top down:  0.8695440292358398
Objective value:  94.0
Time to compute top down:  4.533036470413208
Objective value:  102.0
Time to compute top down:  0.05494832992553711
Objective value:  99.0
Time to compute top down:  1.5320007801055908
Objective value:  328.0
Time to compute top down:  10.39096999168396
Objective value:  680.0
Time to compute top down:  32.741488218307495
Objective value:  839.0
Time to compute top down:  0.07694554328918457
Objective value:  132.0
Time to compute top down:  1.0392091274261475
Objective value:  223.0
Time to compute top down:  10.90440821647644
Objective value:  464.0
Time to compute top down:  31.84273076057434
Objective value:  584.0
Time to compute top down:  0.04231524467468262
Objective value:  75.0
Time to compute top down:  0.7338790893554688
Objective value:  131.0
Time to compute top down:  5.401456356048584
Objective value:  258.0
Time to compute top down:  23.630864143371582
Objective value:  369.0
Time to compute top down:  0.040022850036621094
Objective value:  58.0
Time to compute top down:  0.7041194438934326
Objective value:  140.0
Time to compute top down:  2.7700655460357666
Objective value:  155.0
Time to compute top down:  8.230437278747559
Objective value:  198.0
Time to compute top down:  0.09099292755126953
Objective value:  174.0
Time to compute top down:  3.5233681201934814
Objective value:  734.0
Time to compute top down:  13.421885251998901
Objective value:  1038.0
Time to compute top down:  54.40297842025757
Objective value:  1095.0
Time to compute top down:  0.13596606254577637
Objective value:  268.0
Time to compute top down:  2.5902295112609863
Objective value:  446.0
Time to compute top down:  11.55078649520874
Objective value:  518.0
Time to compute top down:  57.652663469314575
Objective value:  967.0
Time to compute top down:  0.09793233871459961
Objective value:  116.0
Time to compute top down:  1.261897325515747
Objective value:  176.0
Time to compute top down:  10.832499980926514
Objective value:  461.0
Time to compute top down:  32.310951232910156
Objective value:  396.0
Time to compute top down:  0.10201358795166016
Objective value:  101.0
Time to compute top down:  0.9366278648376465
Objective value:  185.0
Time to compute top down:  6.674369812011719
Objective value:  207.0
Time to compute top down:  25.42937159538269
Objective value:  348.0
