Time to compute top down:  0.03793525695800781
Objective value:  68
Time to compute top down:  0.35339999198913574
Objective value:  131
Time to compute top down:  2.4171838760375977
Objective value:  348
Time to compute top down:  7.83868670463562
Objective value:  416
Time to compute top down:  14.641810178756714
Objective value:  380
Time to compute top down:  0.017406463623046875
Objective value:  39
Time to compute top down:  0.16452312469482422
Objective value:  62
Time to compute top down:  1.5696823596954346
Objective value:  194
Time to compute top down:  6.885437726974487
Objective value:  340
Time to compute top down:  18.044474363327026
Objective value:  434
Time to compute top down:  0.02584385871887207
Objective value:  43
Time to compute top down:  0.3290722370147705
Objective value:  103
Time to compute top down:  1.3291196823120117
Objective value:  135
Time to compute top down:  4.996071100234985
Objective value:  170
Time to compute top down:  8.610992908477783
Objective value:  196
Time to compute top down:  0.006878376007080078
Objective value:  26
Time to compute top down:  0.05195808410644531
Objective value:  66
Time to compute top down:  0.8016583919525146
Objective value:  91
Time to compute top down:  2.9852511882781982
Objective value:  129
Time to compute top down:  11.101191520690918
Objective value:  168
Time to compute top down:  0.11881065368652344
Objective value:  143
Time to compute top down:  0.8349354267120361
Objective value:  186
Time to compute top down:  4.853170156478882
Objective value:  451
Time to compute top down:  13.444724798202515
Objective value:  786
Time to compute top down:  29.50776481628418
Objective value:  768
Time to compute top down:  0.07795023918151855
Objective value:  111
Time to compute top down:  0.8422327041625977
Objective value:  200
Time to compute top down:  3.9583511352539062
Objective value:  400
Time to compute top down:  14.659655332565308
Objective value:  547
Time to compute top down:  49.24117374420166
Objective value:  893
Time to compute top down:  0.06123495101928711
Objective value:  68
Time to compute top down:  0.7571418285369873
Objective value:  193
Time to compute top down:  3.0921168327331543
Objective value:  289
Time to compute top down:  11.877012729644775
Objective value:  394
Time to compute top down:  31.065319061279297
Objective value:  430
Time to compute top down:  0.02006697654724121
Objective value:  64
Time to compute top down:  0.8533225059509277
Objective value:  140
Time to compute top down:  1.2359352111816406
Objective value:  169
Time to compute top down:  5.052435636520386
Objective value:  235
Time to compute top down:  13.63806962966919
Objective value:  283
Time to compute top down:  0.13249421119689941
Objective value:  207
Time to compute top down:  1.8486974239349365
Objective value:  476
Time to compute top down:  8.7214937210083
Objective value:  841
Time to compute top down:  28.83087682723999
Objective value:  1124
Time to compute top down:  64.59551072120667
Objective value:  1492
Time to compute top down:  0.1586134433746338
Objective value:  111
Time to compute top down:  1.851283311843872
Objective value:  442
Time to compute top down:  7.234499454498291
Objective value:  548
Time to compute top down:  33.4014573097229
Objective value:  823
Time to compute top down:  91.446368932724
Objective value:  1224
Time to compute top down:  0.08552432060241699
Objective value:  114
Time to compute top down:  1.3987390995025635
Objective value:  227
Time to compute top down:  6.9932639598846436
Objective value:  420
Time to compute top down:  18.707189083099365
Objective value:  569
Time to compute top down:  65.73506331443787
Objective value:  755
Time to compute top down:  0.0762639045715332
Objective value:  68
Time to compute top down:  0.5258302688598633
Objective value:  151
Time to compute top down:  4.267923831939697
Objective value:  241
Time to compute top down:  14.978476524353027
Objective value:  314
Time to compute top down:  46.62020921707153
Objective value:  508
