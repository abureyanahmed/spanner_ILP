Time to compute top down: 70.66318035125732
Objective value: 931
Time to compute top down: 69.43335199356079
Objective value: 678
Time to compute top down: 52.669960260391235
Objective value: 340
Time to compute top down: 32.88766002655029
Objective value: 234
Time to compute top down: 152.7573583126068
Objective value: 1898
Time to compute top down: 154.5635702610016
Objective value: 1368
Time to compute top down: 140.17551064491272
Objective value: 749
Time to compute top down: 94.08905506134033
Objective value: 476
Time to compute top down: 230.8305525779724
Objective value: 2715
Time to compute top down: 234.2731053829193
Objective value: 2013
Time to compute top down: 199.85790967941284
Objective value: 1064
Time to compute top down: 132.13567924499512
Objective value: 682
Time to compute top down: 311.82969546318054
Objective value: 3661
Time to compute top down: 319.0845181941986
Objective value: 2665
Time to compute top down: 255.05957460403442
Objective value: 1391
Time to compute top down: 172.52720522880554
Objective value: 910
Time to compute top down: 381.8926877975464
Objective value: 4548
Time to compute top down: 384.40286684036255
Objective value: 3327
Time to compute top down: 324.1963222026825
Objective value: 1753
Time to compute top down: 214.00133967399597
Objective value: 1129
Time to compute top down: 1591.1051301956177
Objective value: 3029
Time to compute top down: 1781.2376780509949
Objective value: 2268
Time to compute top down: 1320.2924935817719
Objective value: 1184
Time to compute top down: 608.3256866931915
Objective value: 604
Time to compute top down: 3611.1697478294373
Objective value: 6024
Time to compute top down: 3868.1598720550537
Objective value: 4475
Time to compute top down: 3092.939196586609
Objective value: 2343
Time to compute top down: 1460.7551729679108
Objective value: 1206
Time to compute top down: 5606.098295211792
Objective value: 8971
Time to compute top down: 5886.601658821106
Objective value: 6711
Time to compute top down: 4858.952937364578
Objective value: 3473
Time to compute top down: 2297.126519203186
Objective value: 1782
Time to compute top down: 7977.835072755814
Objective value: 11866
Time to compute top down: 8789.788897514343
Objective value: 8927
Time to compute top down: 6724.062759876251
Objective value: 4675
Time to compute top down: 3084.2457914352417
Objective value: 2385
Time to compute top down: 9980.528873682022
Objective value: 14707
Time to compute top down: 10495.554010152817
Objective value: 11061
Time to compute top down: 8356.699312925339
Objective value: 5767
Time to compute top down: 4168.042749166489
Objective value: 2966
Time to compute top down: 10867.978530406952
Objective value: 5068
Time to compute top down: 10850.800776004791
Objective value: 3750
Time to compute top down: 7755.232701778412
Objective value: 1640
Time to compute top down: 3663.1483192443848
Objective value: 804
Time to compute top down: 22534.561863183975
Objective value: 10029
