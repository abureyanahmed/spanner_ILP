###===================
#!/bin/bash
#PBS -l select=1:ncpus=2:mem=12gb:pcmem=6gb -l walltime=60:00:00
#PBS -l cput=62:00:00
#PBS -q high_pri
#PBS -W group_list=mstrout
###-------------------

echo "Node name:"
hostname

cd /extra/abureyanahmed/Graph_spanners
module load python/3.5/3.5.5
python3 bot_up_approx_consistent.py

