###===================
#!/bin/bash
#PBS -l select=1:ncpus=1:mem=6gb:pcmem=6gb -l walltime=00:10:00
#PBS -q debug
#PBS -W group_list=mstrout
###-------------------

cd /extra/abureyanahmed/Graph_spanners
module load python/3.5
module load matlab/r2018b
python3 spanner_column_generation_correction.py

