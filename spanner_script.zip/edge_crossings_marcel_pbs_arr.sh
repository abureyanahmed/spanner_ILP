###===================
#!/bin/bash
#PBS -l select=1:ncpus=1:mem=6gb:pcmem=6gb -l walltime=05:00:00
#PBS -l cput=05:00:00
#PBS -q windfall
#PBS -W group_list=mstrout
###-------------------

echo "Node name:"
hostname

cd /extra/abureyanahmed/GD2018
module load python/3.5/3.5.5
python3 run_with_param.py < log_files_community_pbs_arr/input_$PBS_ARRAY_INDEX.dat > log_files_community_pbs_arr/output_$PBS_ARRAY_INDEX.dat 2> log_files_community_pbs_arr/error_$PBS_ARRAY_INDEX.dat

