###===================
#!/bin/bash
#PBS -l select=1:ncpus=2:mem=12gb:pcmem=6gb -l walltime=40:00:00
#PBS -l cput=45:00:00
#PBS -q standard
#PBS -W group_list=kobourov
###-------------------

cd /extra/abureyanahmed/Graph_spanners
module load python/3.5
python3 spanner_exact_algorithm_only_lp.py erdos_renyi_one_level_2 graph_40_1 8


