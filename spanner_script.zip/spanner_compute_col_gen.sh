###===================
#!/bin/bash
#PBS -l select=1:ncpus=2:mem=12gb:pcmem=6gb -l walltime=40:00:00
#PBS -l cput=45:00:00
#PBS -q high_pri
#PBS -W group_list=mstrout
###-------------------

cd /extra/abureyanahmed/Graph_spanners
module load python/3.5
python3 spanner_column_generation_correction.py

