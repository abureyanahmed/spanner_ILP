###===================
#!/bin/bash
#PBS -l select=1:ncpus=14:mem=84gb:pcmem=6gb -l walltime=8:00:00
#PBS -l cput=112:00:00
#PBS -q high_pri
#PBS -W group_list=mstrout
###-------------------

cd /extra/abureyanahmed/Graph_spanners
module load python/3.5
python3 spanner_exact_algorithm_only_lp.py erdos_renyi_one_level_2 graph_60_1 2


